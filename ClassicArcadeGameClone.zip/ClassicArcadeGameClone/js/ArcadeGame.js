// The heart matrix is 6 rows x 5 colums
// The canvas is col: 101 by row 83
//Enemy bugs move across the 3 rows only

//Global Variables

var games = 0;
var playerLives = 3;
var playerScore = 0;
var audio = new Audio();
var dt; //used globally to represent time-distance
var player; // used globally

// Function called by the engine.js during Init - so it's only called
// once at the start of the game.  Go Darth!
function renderOnce() {
	audio.src = 'sounds/Frogger.mp3';
	audio.play();
}

//Enemy Class
var Enemy = function (x,y,speed) {
	this.sprite = 'images/ghost.gif';
	this.x = x;
	this.y = y;
	this.speed = speed;
	
};
 
 let speedIncreament = 40;

// Some Enemies will move at different speeds
Enemy.prototype.randomSpeed = function (){
    this.speed = speedIncreament * Math.floor(Math.random() * 10 + 1);
     
};

// Update the enemy's position, required method for game
// Parameter: dt -- time distance between ticks
Enemy.prototype.update = function (dt) {
	// You should multiply any movement by the dt parameter
	// which will ensure the game runs at the same speed for
	// all computers.
	  this.x = this.x + this.speed * dt;
    // Reset speed of enemy
    this.offScreenX = 505;
    this.startingX = -100;
    if (this.x >= this.offScreenX) {
        this.x = this.startingX;
        this.randomSpeed();
    }
     this.checkCollision();
};


// Draw the enemy on the screen, required method for game
Enemy.prototype.render = function () {
	ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};

Enemy.prototype.checkCollision = function() {

    var playerBox = {x: player.x, y: player.y, width: 50, height: 40};
    var enemyBox = {x: this.x, y: this.y, width: 60, height: 70};
    if (playerBox.x < enemyBox.x + enemyBox.width &&
        playerBox.x + playerBox.width > enemyBox.x &&
        playerBox.y < enemyBox.y + enemyBox.height &&
        playerBox.height + playerBox.y > enemyBox.y) {
        this.collisionDetected();
    }
};

Enemy.prototype.collisionDetected = function() {
    player.playerLives -= 1;
    audio.src = 'sounds/Swoosh05.mp3';
    audio.play();
    player.characterReset();
};


// Gems the player should try to pick up
var Gem = function(x,y) {
    this.x = x;
    this.y = y;
    this.sprite = 'images/Gem Green.png';
    this.gemWaitTime = undefined;
};

// Update gem, call checkCollision
Gem.prototype.update = function() {
    this.checkCollision();
};

// Draw the gem to the screen
Gem.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};

//Check for collision
Gem.prototype.checkCollision = function() {

    var playerBox = {x: player.x, y: player.y, width: 50, height: 40};
    var gemBox = {x: this.x, y: this.y, width: 60, height: 70};

    if (playerBox.x < gemBox.x + gemBox.width &&
        playerBox.x + playerBox.width > gemBox.x &&
        playerBox.y < gemBox.y + gemBox.height &&
        playerBox.height + playerBox.y > gemBox.y) {
        this.collisionDetected();
    }
};


// Increase player playerplayerScore when collided with gem and reset the gem
Gem.prototype.collisionDetected = function() {
    this.x = 900;
    this.y = 900;
    player.playerScore += 30;
    this.wait();
};


Gem.prototype.wait = function() {
    this.gemWaitTime = setTimeout( function() {
        gem.gemReset();
    }, 5000);
};

// Reset the gem to a new location
Gem.prototype.gemReset = function() {
    
    this.x = (101 * Math.floor(Math.random() * 4) + 0);
    this.y = (60 + (85 * Math.floor(Math.random() * 3) + 0));
};

// stars the player should try to pick up
var Star = function(x,y) {
    this.x = x;
    this.y = y;
    this.sprite = 'images/Star.png';
    this.heartWaitTime = undefined;
};

// Update star, call checkCollision
Star.prototype.update = function() {
    this.checkCollision();
};

// Draw the star to the screen
Star.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};

// Check for collision
Star.prototype.checkCollision = function() {

    var playerBox = {x: player.x, y: player.y, width: 50, height: 40};
    var heartBox = {x: this.x, y: this.y, width: 60, height: 70};

    if (playerBox.x < heartBox.x + heartBox.width &&
        playerBox.x + playerBox.width > heartBox.x &&
        playerBox.y < heartBox.y + heartBox.height &&
        playerBox.height + playerBox.y > heartBox.y) {
        this.collisionDetected();
    }
};


// Increment of player lives and reset stars
Star.prototype.collisionDetected = function() {
    this.x = 900;
    this.y = 900;
    player.playerLives += 1;
    this.wait();
};

Star.prototype.wait = function() {
    this.StarWaitTime = setTimeout( function() {
        Star.StarReset();
    }, 30000);
};

// Reset the heart to a new location
Star.prototype.StarReset = function() {

    this.x = (101 * Math.floor(Math.random() * 4) + 0);
    this.y = (70 + (85 * Math.floor(Math.random() * 3) + 0));
};

//max lives =3 and playerScore starts at zero, increments by 50
//player class
var Player = function() {
    this.startingX = 200;
    this.startingY = 400;
    this.x = this.startingX;
    this.y = this.startingY;
    this.sprite = 'images/micky.png';
    this.playerScore = 0;
    this.playerLives = 3;
    this.games = 0;
};

// Updates Player's position - try to move player into a new box
Player.prototype.update = function () {
	 if (this.playerLives === 0) {
        reset();
        var endtime;
        audio.src = 'sounds/Bong.mp3'; //restart with 3 lives
        audio.play();
        this.playerLives = 3;
        this.games++;

        // pause after each game
        endtime = Date.now()+3000;
        while (Date.now() < endtime);
    }
};

// Resets the player position to the start position
Player.prototype.characterReset = function() {
    this.startingX = 200;
    this.startingY = 400;
    this.x = this.startingX;
    this.y = this.startingY;
};

// Increase playerScore and increase difficulty when player reaches top of water
Player.prototype.success = function() {
    this.playerScore += 20;
    speedIncreament += 5;
    this.characterReset();
};

 
// Renders player on the canvas
// the initial playerScore of 0
// and your lives (hearts)

Player.prototype.render = function () {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
	// Display the stuff at the top
    // lives, playerScore, Games,  difficulty
    // ctx.fillStyle = "white";
    // ctx.fillRect(170,15,1000,35);
    // ctx.clearRect(170,15,1000,35);

    ctx.font = "18px Verdana";
    ctx.fillStyle = 'yellow';
    ctx.fillText("Score:", 175, 15);
    ctx.fillText(this.playerScore, 175,40);

    ctx.fillText("Games: ", 265,15);
    ctx.fillText(this.games, 265,40);

    ctx.fillText("Difficulty: " + speedIncreament, 360, 40);

    var imageObj = new Image();
    imageObj.src = 'images/Heart.png';
    ctx.clearRect(0, 0, 170, 50);

    //put the x heart playerLives on the top where x is number of playerLives left
    for (i = 0; i < this.playerLives; i++) {
        ctx.drawImage(imageObj, (i) * 45, 0, 50, 50);
    }
};


// move the player on each key press.
// Up key will move the player upward on y-axis
// Down key will move the player downwards
// Right key will move the player to the right on x-axis
// Left key will move the player to the left on x-axis
//

Player.prototype.handleInput = function(allowedKeys) {
   
    switch (allowedKeys) {
        case "left":
            if (this.x > 0) {
                this.x -= 101;
            }
            break;

        case "right":
            if (this.x < 402) {
                this.x += 101;
            }
            break;

        case "up":
            if (this.y < 0) {
                this.success();
            } else {
                this.y -= 83;
            }
            break;

        case "down":
            if (this.y < 400) {
                this.y += 83;
            }
            break;
    }
};
//Instantiate enemies and player objects.
// Now instantiate your	objects.
// Place all enemy objects in an array called allEnemies
	var player = new Player();

    var allEnemies = [];
	for (var i = 0; i<3; i++){
		 var startSpeed = speedIncreament * Math.floor(Math.random() * 10 + 1);
         allEnemies.push(new Enemy(-100, 60 + (85 * i), startSpeed));
	}

    // Instantiate Gem
   var gem = new Gem (101 * Math.floor(Math.random() * 4) + 0, 60 +
    (85 * Math.floor(Math.random() * 3) + 0));

    // Instantiate heart
    var Star = new Star (101 * Math.floor(Math.random() * 4) + 0, 70 +
    (85 * Math.floor(Math.random() * 3) + 0));


// This listens for key presses and sends the keys to your
// Player.handleInput() method. You don't need to modify this.
	var input = function(e) {
    var allowedKeys = {
        37: 'left',
        38: 'up',
        39: 'right',
        40: 'down'
    };
    player.handleInput(allowedKeys[e.keyCode]);
};
document.addEventListener('keyup', input);
